function calculateTotal() {
    const pizzaQty = parseInt(document.getElementById('pizzaQty').value);
    const pepperoniQty = parseInt(document.getElementById('pepperoniQty').value);
    const southernQty = parseInt(document.getElementById('southernQty').value);
    const saladQty = parseInt(document.getElementById('saladQty').value);
    const PastaQty = parseInt(document.getElementById('PastaQty').value);

    const pizzaPrice = 7.00;
    const p-pizzaPrice = 7.50;
    const southernPrice = 10.00;
    const pastaPrice = 7.50;
    const saladPrice = 6.50;

    const total = (pizzaQty * pizzaPrice) + (pepperoniQty*p-pizzaPrice) + (southernQty * southernPrice) + (saladQty * saladPrice)+(pastaPrice*PastaQty);

    document.getElementById('totalAmount').textContent = '$' + total.toFixed(2);
}